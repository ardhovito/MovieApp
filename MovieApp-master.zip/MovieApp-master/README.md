# UAS_MovieApps_MobileProgramming
Anggota Kelompok:
1.Aditya Darma Yuda         223307061
2.Ardho Tri Fadillah        223307064
3.Wahyu Indra Kurniawan     223307086

Proyek ini dibuat untuk memenuhi TUGAS dan UAS Mobile Programming
